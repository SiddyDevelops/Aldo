package com.siddydevelops.aldo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class BookActivity extends AppCompatActivity {

    ImageView bookCoverImage;
    TextView bookName;
    TextView authorName;
    TextView bookDiscription;
    String bookimageUrl;

    Button readBook;
    Button downloadBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        int colorCodeDark = Color.parseColor("#FFFFFF");
        window.setStatusBarColor(colorCodeDark);

        Toolbar toolbar = findViewById(R.id.toolbarBooks);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        readBook = findViewById(R.id.readBook);
        downloadBook = findViewById(R.id.downloadBook);

        bookCoverImage = findViewById(R.id.bookCoverImageView);
        bookName = findViewById(R.id.bookName);
        authorName = findViewById(R.id.authorName);
        bookDiscription = findViewById(R.id.bookDescription);

        Intent intent = getIntent();
        bookName.setText(intent.getStringExtra("BookName"));
        authorName.setText(intent.getStringExtra("AuthorName"));
        bookDiscription.setText(intent.getStringExtra("BookDiscription"));

        bookimageUrl = intent.getStringExtra("ImageUrl");

        Glide.with(this).load(bookimageUrl).into(bookCoverImage);

        readBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentpdf = new Intent(getApplicationContext(),ViewPdfThroughURL.class);
                startActivity(intentpdf);
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home)
        {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}